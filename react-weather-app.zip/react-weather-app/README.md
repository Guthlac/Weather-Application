﻿Hi there, thanks for checking out my weather app.

If you want to see the app in action please open the root folder in the terminal and install the required node modules by inputting "npm install" and then open the developer server by inputting "npm start"

This is my most recent, and therefore my best work.

To see more of my work go to https://github.com/Guthlac

If you would like to contact me you can reach me at:

jordangscholes@gmail.com
07516319431