import React from "react";
import "./Arrow.css";
import smoothscroll from "smoothscroll-polyfill";

const arrow = props => {
  smoothscroll.polyfill();
  const classNames = ["Arrow"];

  if (props.disabled) {
    classNames.push("disabled");
  }


  let arrow, i;

  props.direction === "left" ? (arrow = "<") : (arrow = ">");
  props.direction === "left" ? (i = 0) : (i = 10000);

  return (
    <div
      className={classNames.join(' ')}
      onClick={() => {
        document
          .querySelector(".hours-wrapper")
          .scroll({ top: 0, left: i, behavior: "smooth" });
      }}
    >
      {arrow}
    </div>
  );
};

export default arrow;
