import React from "react";
import "./WeatherHours.css";
import Arrow from "../Arrow/Arrow";
import RainDropsIcon from "../SVG/RainDropsIcon";
import WindArrowIcon from "../SVG/WindArrowIcon";
import Spinner from "../Spinner/Spinner";
const moment = require("moment");

const weatherHours = props => {
  let arrow1, arrow2, WeatherHours;
  let hoursArr = [];
  const disabled = [false, false];

  if (props.scrollPos === "left") {
    disabled[0] = true;
  } else if (props.scrollPos === "right") {
    disabled[1] = true;
  }

  if (props.data) {
    hoursArr = props.data.map((e, i) => {
      let classNames, time;
      const icon = props.iconGet(e.icon);
      const currentTime = moment().format("HH:00");

      i >= 10 ? (time = `${i}:00`) : (time = `0${i}:00`);

      currentTime === time && props.activeDay === 0
        ? (classNames = "time bold")
        : (classNames = "time notBold");

      return (
        <div className="hour" key={i}>
          <div className={classNames}>{time}</div>
          <div className="temperature-wrapper">
            <span className="weather-icon">{icon}</span>
            <span className="temperature">{e.temperature}</span>
          </div>
          <div className="details-wrapper">
            <div className="rain-info info">
              <span className="rain-icon">
                <RainDropsIcon />
              </span>
              <span className="rain-chance small-text">{e.rainChance}</span>
            </div>
            <div className="rain-info info">
              <span
                className="wind-icon"
                style={{ transform: `rotate(${e.windDirection}deg)` }}
              >
                <WindArrowIcon />
              </span>
              <span className="wind-speed small-text">{e.windSpeed}</span>
            </div>
          </div>
        </div>
      );
    });
  }

  if (props.data) {
    arrow1 = <Arrow direction="left" disabled={disabled[0]} />;
    arrow2 = <Arrow direction="right" disabled={disabled[1]} />;
  }

  if (props.loading) {
    WeatherHours = (
      <div className="WeatherHours">
        <div className="hours-spinner-box">
          <Spinner />
        </div>
      </div>
    );
  } else {
    WeatherHours = (
      <div className="WeatherHours">
        {arrow1}
        <div className="hours-wrapper" onScroll={props.scrollPosHandler}>
          {hoursArr}
        </div>
        {arrow2}
      </div>
    );
  }

  return WeatherHours;
};

export default weatherHours;
