import React from "react";
import "./WeatherDays.css";
import Spinner from "../Spinner/Spinner";

const weatherDays = props => {
  let WeatherDays,
    daysArr = [];

  if (props.data) {
    daysArr = props.data.map((e, i) => {
      if (i !== 7) {
        const icon = props.iconGet(e.icon);
        let classNames1, classNames2;

        const onClicks = () => {
          props.activeDayHandler.bind(this, i)();
          props.updateHours();
        };

        i === props.activeDay
          ? (classNames1 = "day active")
          : (classNames1 = "day");

        i === 0
          ? (classNames2 = "day-header current-day")
          : (classNames2 = "day-header");

        return (
          <div className={classNames1} key={i} id={i} onClick={onClicks}>
            <div className={classNames2}>{e.date}</div>
            <div className="weather-info">
              <div className="weather-icon">{icon}</div>
              <div className="temperatures">
                <p className="temperature-highest">{e.highTemp}</p>
                <p className="temperature-lowest">{e.lowTemp}</p>
              </div>
            </div>
          </div>
        );
      } else {
        return null;
      }
    });
  }

  if (props.loading) {
    WeatherDays = (
      <div className="WeatherDays">
        <div className="days-spinner-box">
          <Spinner />
        </div>
      </div>
    );
  } else {
    WeatherDays = (
      <div className="WeatherDays">
        <div className="days-wrapper">{daysArr}</div>
      </div>
    );
  }

  return WeatherDays;
};

export default weatherDays;
