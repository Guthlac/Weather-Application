import React, { Component } from "react";
import "./InputBox.css";
const axios = require("axios");
const options = { spaces: "%20", trim: true };
const urlify = require("urlify").create(options);

class InputBox extends Component {
  constructor(props) {
    super(props);
    this.inputBoxRef = React.createRef();
  }

  state = {
    suggestions: [
      {
        place: "",
        latLong: ""
      }
    ],
    value: "",
    activeSuggestion: 0,
    placeholder: "Please input your location",
    showSuggestions: true,
    shouldTrigger: false
  };

  componentDidMount() {
    document.addEventListener("keydown", this.keyPressHandlers);

    document.addEventListener(
      "mousedown",
      this.clearSuggestionsOnOuterClick,
      false
    );

    document.addEventListener(
      "mousedown",
      this.showSuggestionsOnInnerClick,
      false
    );
  }

  suggestionHandler = ({ target }) => {
    const url = urlify(target.value);

    this.setState({ value: url });

    if (!url) {
      this.clearSuggestionsHandler();
      return null;
    }

    setTimeout(() => {
      if (url !== this.state.value) {
        return null;
      }

      axios
        .get(
          `https://api.mapbox.com/geocoding/v5/mapbox.places/${url}.json?access_token=pk.eyJ1IjoiZ3V0aGxhYyIsImEiOiJjanhibGExM3UwY2hxM25wbjVjZDE3OTRqIn0.xbtTcjr71KQjWvupWQANWQ`
        )
        .then(res => {
          const suggestions = res.data.features.map(data => {
            const place = this.formatPlace(data.place_name);
            return {
              place: place,
              latLong: `${JSON.stringify(data.center[1])},${JSON.stringify(
                data.center[0]
              )}`
            };
          });

          this.setState({ suggestions: suggestions, shouldTrigger: true });
        })
        .catch(err => {
          alert(err);
        });
    }, 400);
  };

  formatPlace = place => {
    let idx,
      indexArr = [];

    idx = place.indexOf(",");
    while (idx !== -1) {
      indexArr.push(idx);
      idx = place.indexOf(",", idx + 1);
    }

    if (indexArr[0] !== -1 || indexArr[1]) {
      return place.slice(0, indexArr[1]);
    } else if (indexArr[0] !== -1 || !indexArr[1]) {
      return place.slice(0, indexArr[0]);
    } else {
      return place;
    }
  };

  formatPlaceSimple = i => {
    const place = this.state.suggestions[i].place;
    const idx = place.indexOf(",");
    let newPlace;

    if (idx !== -1) {
      newPlace = place.slice(0, idx);
    } else {
      newPlace = place;
    }

    return newPlace;
  };

  clearSuggestionsHandler = () => {
    document.querySelector(".input-box").value = "";

    const newState = this.state;
    newState.suggestions = [{ place: "", latLong: "" }];
    newState.shouldTrigger = false;

    this.setState({
      state: newState
    });
  };

  clearSuggestionsOnOuterClick = e => {
    if (!this.inputBoxRef.current.contains(e.target)) {
      this.setState({
        activeSuggestion: 0,
        shouldTrigger: false,
        showSuggestions: false
      });
    }
  };

  showSuggestionsOnInnerClick = e => {
    if (
      this.inputBoxRef.current.contains(e.target) &&
      this.state.suggestions[0]
    ) {
      this.setState({ showSuggestions: true, shouldTrigger: true });
    }
  };

  hoverInHandler = int => {
    const newState = this.state;
    newState.activeSuggestion = int;
    this.setState({ state: newState });
  };

  hoverOutHandler = () => {
    this.setState({ activeSuggestion: -1 });
  };

  enterPressHandler = event => {
    if (event.keyCode === 13 && this.state.showSuggestions) {
      let i = this.state.activeSuggestion;
      this.placeholderHandler(i);

      if (i === -1) {
        i = 0;
      }

      this.props.suggestionInteractHandler.bind(
        this,
        this.state.suggestions[i].latLong
      )();
      this.clearSuggestionsHandler();
      this.setState({ activeSuggestion: 0 });
      document.querySelector(".input-box").blur();
    }
  };

  escPressHandler = event => {
    if (event.keyCode === 27) {
      this.setState({
        showSuggestions: false,
        activeSuggestion: 0,
        shouldTrigger: false
      });
    }
  };

  downPressHandler = event => {
    const i = this.state.activeSuggestion;
    if (this.state.suggestions[0]) {
      if (i < this.state.suggestions.length - 1) {
        if (event.keyCode === 40) {
          this.setState({ activeSuggestion: i + 1 });
        }
      }
    }
  };

  upPressHandler = event => {
    const i = this.state.activeSuggestion;

    if (i > 0) {
      if (event.keyCode === 38) {
        this.setState({ activeSuggestion: i - 1 });
      }
    }
  };

  keyPressHandlers = event => {
    if (this.state.suggestions[0] && this.state.shouldTrigger) {
      this.enterPressHandler(event);
      this.downPressHandler(event);
      this.upPressHandler(event);
    }
    this.escPressHandler(event);
  };

  placeholderHandler = i => {
    const placeholder = this.formatPlaceSimple(i);
    this.setState({ placeholder: placeholder });
  };

  render() {
    let classNames;
    const suggestions = this.state.suggestions;
    if (suggestions[0]) {
      if (suggestions[0].place) {
        classNames = "suggestions";
      }
    }

    if (!this.state.showSuggestions) {
      classNames = "suggestions hidden";
    }

    const inputBox = (
      <div
        className="input-box-wrapper"
        id="input-box-wrapper"
        ref={this.inputBoxRef}
      >
        <div className="box-button-wrapper">
          <input
            type="text"
            className="input-box"
            placeholder={this.state.placeholder}
            onChange={this.suggestionHandler}
          />
          {/* <button className="input-box-button">
            <MagnifyingGlass />
          </button> */}
        </div>
        <div className={classNames} onMouseLeave={this.hoverOutHandler}>
          {suggestions.map((e, i) => {
            if (e.place) {
              let suggestionClasses = "suggestion";

              if (i === this.state.activeSuggestion) {
                suggestionClasses = "suggestion active-suggestion";
              }
              return (
                <p
                  className={suggestionClasses}
                  onClick={() => {
                    this.props.suggestionInteractHandler.bind(
                      this,
                      this.state.suggestions[i].latLong
                    )();
                    this.placeholderHandler.bind(this, i)();
                    this.clearSuggestionsHandler();
                  }}
                  onMouseEnter={this.hoverInHandler.bind(this, i)}
                  key={i}
                >
                  {e.place}
                </p>
              );
            }
            return null;
          })}
        </div>
      </div>
    );

    return inputBox;
  }
}

export default InputBox;
