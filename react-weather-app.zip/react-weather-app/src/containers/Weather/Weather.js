import React, { Component } from "react";
import "./Weather.css";
import Header from "../../components/Header/Header";
import WeatherDays from "../../components/WeatherDays/WeatherDays";
import WeatherHours from "../../components/WeatherHours/WeatherHours";
import InputBox from "../../components/InputBox/InputBox";
import SunIcon from "../../components/SVG/SunIcon";
import MoonIcon from "../../components/SVG/MoonIcon";
import RainIcon from "../../components/SVG/RainIcon";
import SnowIcon from "../../components/SVG/SnowIcon";
import SleetIcon from "../../components/SVG/SleetIcon";
import WindyIcon from "../../components/SVG/WindyIcon";
import FogIcon from "../../components/SVG/FogIcon";
import CloudIcon from "../../components/SVG/CloudIcon";
import SunCloudIcon from "../../components/SVG/SunCloudIcon";
import MoonCloudIcon from "../../components/SVG/MoonCloudIcon";
const moment = require("moment");
const axios = require("axios");
const changeCase = require("change-case");

class Weather extends Component {
  state = {
    data: {},
    scrollPos: "left",
    shouldScroll: true,
    activeDay: 0,
    latLong: "",
    daysLoading: false,
    hoursLoading: false
  };

  // Update state based on lat/long gotten from the input box component
  suggestionInteractHandler = latLong => {
    const newState = this.state;
    newState.latLong = latLong;
    this.setState({ state: newState });

    this.getWeatherDataHandler();
  };

  getWeatherDataHandler = () => {
    this.setState({ daysLoading: true, hoursLoading: true });
    setTimeout(() => {
      axios
        .get(this.getDayDataHandler())
        .then(res => {
          this.setState({ daysLoading: false });
          this.dayDataHandler(res);
          console.log(res.data.daily.data[this.state.activeDay].time);
          return res.data.daily.data[this.state.activeDay].time;
        })
        .then(time => {
          axios
            .get(this.getHourDataHandler(time))
            .then(res => {
              console.log(res);
              this.setState({ hoursLoading: false });
              this.hourDataHandler(res);
            })
            .then(() => {
              this.startScrollPositionHandler();
            })
            .catch(err => {
              this.setState({ daysLoading: false, hoursLoading: false });
              alert(err);
            });
        });
    }, 1000);
  };

  // Update hourly data based on selected day
  updateHourlyDataHandler = () => {
    this.setState({ hoursLoading: true });

    setTimeout(() => {
      const time = this.state.data.daily[this.state.activeDay].timeCode;
      axios.get(this.getHourDataHandler(time)).then(res => {
        this.hourDataHandler(res);
        this.setState({ hoursLoading: false });
        this.startScrollPositionHandler();
        console.log(this.state.data);
      });
    }, 350);
  };

  // Make ajax call for daily weather data
  getDayDataHandler = () => {
    return `https://cors-anywhere.herokuapp.com/https://api.darksky.net/forecast/6c7dead78b4c7731f4adebaa6c97a803/${
      this.state.latLong
    }?exclude=[currently,minutely,hourly,alerts,flags]`;
  };

  // Make ajax call for hourly weather data
  getHourDataHandler = time => {
    return `https://cors-anywhere.herokuapp.com/https://api.darksky.net/forecast/6c7dead78b4c7731f4adebaa6c97a803/${
      this.state.latLong
    },${time}?exclude=[currently,daily,minutely,alerts,flags]`;
  };

  // Manage daily data from ajax call
  dayDataHandler = res => {
    const newData = this.state.data;

    newData.daily = res.data.daily.data.map(e => {
      return {
        timeCode: e.time,
        date: this.formatTimeDaily(e.time),
        icon: e.icon,
        highTemp: this.convertFahrenheit(e.temperatureMax),
        lowTemp: this.convertFahrenheit(e.temperatureMin)
      };
    });

    this.setState({ data: newData });
  };

  // Manage hourly data from ajax call
  hourDataHandler = res => {
    const newData = this.state.data;
    newData.hourly = res.data.hourly.data.map(e => {
      return {
        time: this.formatTimeHourly(e.time),
        icon: e.icon,
        temperature: this.convertFahrenheit(e.temperature),
        rainChance: Math.round(e.precipProbability * 100),
        windDirection: e.windBearing,
        windSpeed: Math.round(e.windSpeed)
      };
    });
    this.setState({ data: newData });
  };

  convertFahrenheit = temp => {
    const celcius = Math.round((temp - 32) * (5 / 9));
    return `${celcius}°C`;
  };

  formatTimeDaily = timeStamp => {
    const time = moment.unix(timeStamp).format("MMM Do");
    return time.slice(0, -2);
  };

  formatTimeHourly = timeStamp => {
    const time = moment.unix(timeStamp).format("HH:mm");
    return time;
  };

  startScrollPositionHandler = () => {
    document
      .querySelector(".hours-wrapper")
      .scrollTo(document.querySelector(".hours-wrapper").scrollWidth / 4, 0);
  };

  // Track position of scroll in hours wrapper div
  scrollPositionHandler = () => {
    let scrollPos;
    const div = document.querySelector(".hours-wrapper");
    const scrollPosInt = div.scrollLeft;
    const newState = this.state;

    if (scrollPosInt - 1 < 0) {
      scrollPos = "left";
    } else if (scrollPosInt + 1 > div.scrollWidth - div.clientWidth) {
      scrollPos = "right";
    } else {
      scrollPos = " middle";
    }

    newState.scrollPos = scrollPos;

    this.setState({ state: newState });
  };

  activeDayHandler = id => {
    const newState = this.state;
    newState.activeDay = id;

    this.setState({ state: newState });
    console.log(this.state.activeDay);
  };

  iconHandler = icon => {
    const iconPairs = {
      clearDay: <SunIcon />,
      clearNight: <MoonIcon />,
      rain: <RainIcon />,
      snow: <SnowIcon />,
      sleet: <SleetIcon />,
      wind: <WindyIcon />,
      fog: <FogIcon />,
      cloudy: <CloudIcon />,
      partlyCloudyDay: <SunCloudIcon />,
      partlyCloudyNight: <MoonCloudIcon />
    };

    return iconPairs[changeCase.camelCase(icon)];
  };

  render() {
    return (
      <div className="Weather">
        <Header />
        <InputBox suggestionInteractHandler={this.suggestionInteractHandler} />
        <WeatherDays
          activeDayHandler={this.activeDayHandler}
          updateHours={this.updateHourlyDataHandler}
          iconGet={this.iconHandler}
          activeDay={this.state.activeDay}
          data={this.state.data.daily}
          loading={this.state.daysLoading}
        />
        <WeatherHours
          iconGet={this.iconHandler}
          data={this.state.data.hourly}
          scrollPosHandler={this.scrollPositionHandler}
          scrollPos={this.state.scrollPos}
          activeDay={this.state.activeDay}
          loading={this.state.hoursLoading}
        />
      </div>
    );
  }
}

export default Weather;
